use toys_group_db;

-- creazione dell'entità products
create table products (
productID int,
productName varchar(60),
productPrice decimal(10,2),
categoryID int,
categoryName varchar(50),
releaseDate date,
PRIMARY KEY(productID));


-- creazione dell'entità regions
create table regions (
regionID int,
regionName varchar(50),
country varchar(50),
capital varchar(50),
primary key(regionID));


-- creazione dell'entità sales
create table sales (
saleID int,
productID int,
regionID int,
quantity int,
saleDate date,
primary key (saleID),
foreign key (productID) references products(productID),
foreign key (regionID) references regions(regionID));



-- inserisco i dati nella tabella products
INSERT INTO products (productID, productName, productPrice, categoryID, categoryName, releaseDate)
VALUES 
(1, 'Plush Teddy Bear', 20, 101, 'Stuffed Animals', '2023-01-01'),
(2, 'LEGO Space Shuttle', 50, 102, 'Building Blocks', '2023-02-15'),
(3, 'Barbie Dreamhouse', 100, 103, 'Dolls and Accessories', '2023-03-10'),
(4, 'Action Figure Heroes', 30, 104, 'Action Figures', '2023-04-05'),
(5, 'Board Game Bonanza', 40, 105, 'Board Games', '2023-05-20'),
(6, 'Remote Control Car', 35, 106, 'Remote Control Toys', '2023-06-15'),
(7, 'Puzzle Paradise', 25, 107, 'Puzzles', '2023-07-10'),
(8, 'Science Lab Explorer', 60, 108, 'Educational Toys', '2023-08-25'),
(9, 'PlastiCraft Art Kit', 15, 109, 'Arts and Crafts', '2023-09-10'),
(10, 'Music Maestro Keyboard', 55, 110, 'Musical Instruments', '2023-10-05'),
(11, 'Cuddly Dinosaur', 18, 101, 'Stuffed Animals', '2023-11-15'),
(12, 'City Building Blocks', 45, 102, 'Building Blocks', '2023-12-01'),
(13, 'Fashion Doll Set', 90, 103, 'Dolls and Accessories', '2023-12-25'),
(14, 'Superhero Action Duo', 28, 104, 'Action Figures', '2024-01-10'),
(15, 'Family Board Game Pack', 55, 105, 'Board Games', '2024-02-14'),
(16, 'Off-Road RC Monster', 38, 106, 'Remote Control Toys', '2024-03-20'),
(17, 'Enchanting Jigsaw Set', 30, 107, 'Puzzles', '2024-04-05'),
(18, 'Chemistry Lab Kit', 75, 108, 'Educational Toys', '2024-05-01'),
(19, 'DIY Craft Masterpiece', 20, 109, 'Arts and Crafts', '2024-06-15'),
(20, 'Miniature Piano', 50, 110, 'Musical Instruments', '2024-07-10');



-- inserisco i dati nella tabella regions
INSERT INTO regions (regionID, regionName, country, capital)
VALUES 
(1, 'WestEurope', 'France', 'Paris'),
(2, 'WestEurope', 'Germany', 'Berlin'),
(3, 'WestEurope', 'Belgium', 'Brussels'),
(4, 'WestEurope', 'Netherlands', 'Amsterdam'),
(5, 'NorthEurope', 'Sweden', 'Stockholm'),
(6, 'NorthEurope', 'Norway', 'Oslo'),
(7, 'NorthEurope', 'Denmark', 'Copenhagen'),
(8, 'SouthEurope', 'Italy', 'Rome'),
(9, 'SouthEurope', 'Spain', 'Madrid'),
(10, 'SouthEurope', 'Greece', 'Athens'),
(11, 'EastEurope', 'Poland', 'Warsaw'),
(12, 'EastEurope', 'Czech Republic', 'Prague'),
(13, 'EastEurope', 'Hungary', 'Budapest'),
(14, 'NorthAmerica', 'Canada', 'Ottawa'),
(15, 'NorthAmerica', 'United States', 'Washington'),
(16, 'SouthAmerica', 'Brazil', 'Brasilia'),
(17, 'SouthAmerica', 'Argentina', 'Buenos Aires');


-- inserisco i dati nella tabella sales
INSERT INTO sales (saleID, productID, regionID, quantity, saleDate)
VALUES 
(1, 1, 1, 5,'2023-01-05'),
(2, 1, 2, 3,'2023-01-10'),
(3, 3, 3, 2,'2023-02-15'),
(4, 4, 4, 8,'2023-03-02'),
(5, 5, 5, 4,'2023-03-20'),
(6, 13, 1, 1,'2023-04-01'),
(7, 7, 3, 3,'2023-05-12'),
(8, 8, 6, 2,'2023-06-18'),
(9, 9, 2, 1,'2023-07-25'),
(11, 11, 4, 7,'2023-09-05'),
(12, 2, 7, 4,'2023-10-15'),
(13, 13, 2, 2,'2023-11-20'),
(14, 14, 3, 6,'2023-12-10'),
(15, 15, 1, 3,'2024-01-05'),
(16, 11, 10, 30,'2024-01-17'),
(17, 14, 13, 25,'2024-01-11'),
(18, 16, 6, 12,'2024-01-10'),
(19, 17, 4, 19,'2023-12-22'),
(20, 18, 15, 29,'2024-01-01'),
(21, 13, 8, 19,'2024-01-18'),
(22, 13, 8, 23,'2024-01-19'),
(23, 12, 14, 22,'2024-01-17'),
(24, 13, 1, 27,'2023-12-18'),
(25, 12, 6, 17,'2024-01-14');



-- mostra le tabelle
show tables;

-- Verificare che i campi definiti come PK siano univoci. 
SELECT COUNT(*) = (SELECT COUNT(DISTINCT regionID) FROM regions) AS uniqueRegion,
       COUNT(*) = (SELECT COUNT(DISTINCT productID) FROM products) AS uniqueProduct,
       COUNT(*) = (SELECT COUNT(DISTINCT saleID) FROM sales) AS uniqueSales;


-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
select p.productID, p.productName, sum(p.productPrice*s.quantity) as total, year(s.saleDate) as year
from sales s
join products p using(productID)
group by year(s.saleDate), p.productID, p.productName
order by year;

-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
select r.country, sum(p.productPrice*s.quantity) as total, year(s.saleDate) as year
from products p
join sales s using(productID)
join regions r using(regionID)
group by year, r.country
order by year desc, total desc;


-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
select p.categoryID, p.categoryName, sum(s.quantity) as totalQuantity
from sales s
join products p using(productID)
group by p.categoryID, p.categoryName
order by totalQuantity desc
limit 1;


-- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- approccio 1
select p.productID, p.productName
from products p
left join sales s using(productID)
where s.productID is null;

-- approccio 2
select productID, productName 
from products 
where productID not in (select productID from sales);

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
select productID, max(saleDate) as lastDate
from sales 
group by productID;

/*BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, 
la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della 
regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati 
più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)*/

select s.saleID, s.saleDate, p.productName, p.categoryID, 
p.categoryName, r.country, r.regionName,
case when curdate() - s.saleDate > 180 then true else false end as morethan180day
from products p
join sales s using(productID)
join regions r using(regionID);





